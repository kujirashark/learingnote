from django.conf.urls import url

from user import views

urlpatterns = [
    # 用户登录页面
    url(r'login/', views.login, name='login'),
    # 用户注册页面
    url(r'register/', views.register, name='register'),
    # 用户登出页面
    url(r'logout/', views.logout, name='logout'),

    # 权限测试
    # url(r'userper/',views.userper,name='userper'),

]
