from django.db import models


# 创建用户model
class Users(models.Model):
    user = models.CharField(max_length=20)
    password = models.CharField(max_length=255)
    ticket = models.CharField(max_length=30)
    u_create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'tb_user'


# 创建权限model
class Permission(models.Model):
    p_name = models.CharField(max_length=10)
    p_en = models.CharField(max_length=10)

    class Meta:
        db_table = 'tb_permission'


# 创建角色meodel
class Role(models.Model):
    r_name = models.CharField(max_length=10)
    u = models.OneToOneField(Users)
    r_p = models.ManyToManyField(Permission)

    class Meta:
        db_table = 'tb_role'
