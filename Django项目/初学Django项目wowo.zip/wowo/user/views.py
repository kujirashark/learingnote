import random

from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.core.urlresolvers import reverse
from user.models import Users, Role

"""
自定义登录注册
"""


def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    if request.method == 'POST':
        # 回去注册页面传入的用户名
        user = request.POST.get('username')
        # 获取注册页面传入的密码
        pwd1 = request.POST.get('pwd1')
        # 获取注册页面传入的确认密码
        pwd2 = request.POST.get('pwd2')

    # all()函数数判断是否值为空,如果为空就返回Ture,反之为False.
    if not all([user, pwd1, pwd2]):
        msg = '注册信息不能为空'
        return render(request, 'register.html', {'msg': msg})
    if pwd1 != pwd2:
        msg = '两次密码不一致'
        return render(request, 'register.html', {'msg': msg})

    # 使用自定义的model创建用户
    Users.objects.create(user=user, password=pwd1)
    # 用户注册成功重定向好登录页面
    return HttpResponseRedirect(reverse('user:login'))


def login(request):
    if request.method == 'GET':
        return render(request, 'login.html')

    if request.method == 'POST':
        # 获取登录页面输入的username.
        username = request.POST['username']
        password = request.POST['password']

        # 核对用户名和密码是否在数据库
        user = Users.objects.filter(user=username, password=password).first()

        if user:
            # 先申请随机的字符串,长度为28
            s = '1qaz2wsx3edc4rfv5tgb6yhn7ujm8ik,9ol.;p0QAZWSXEDCRFVTGBYHNUJMIKOLP'
            # 定义一个票的空变量
            ticket = ''
            # 从上面的s字符串中随机产生一个28位的字符串,用于登录的验证
            for i in range(28):
                ticket += random.choice(s)
            # 将生成好的票保存在服务器的数据库
            user.ticket = ticket
            user.save()

            response = HttpResponseRedirect(reverse('wo:index'))
            # 设置客户端的票(ticket)
            response.set_cookie('ticket', ticket)
            # 如果成功 重定向到首页
            return response
        # 如果登录失败提示运行下面的程序 并返回给客户端
        else:
            msg = '用户名或者密码错误'
            return render(request, 'login.html', {'msg': msg})


def logout(request):
    if request.method == 'GET':
        response = HttpResponseRedirect(reverse('user:login'))
        # 删除响应中的ticket
        response.delete_cookie('ticket')
        return response

#权限的测试
# def userper(request):
#
#     user = Users.objects.filter(user='admin').first()
#
#     user.role.r_p.all()
#
#     pass

