from django.db.models import Q
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
from django.core.urlresolvers import reverse
from django.core.paginator import Paginator
from wo.models import Student, Grade

"""
首页
"""


def index(request):
    if request.method == 'GET':
        return render(request, 'index.html')


"""
显示学生信息
"""


def student(request):
    if request.method == 'GET':
        # 获取get请求获取传入的页码的url参数如果获取不到参数就给他赋一个默认值1.
        page_num = request.GET.get('page_num', 1)
        # 获取所有的学生数据 ,我这有假删除的数据所以添加了一个过滤参数
        # 正常情况下应该是 students = list(Student.objects.all())
        students = list(Student.objects.all().filter(stu_delete=0))
        # 计算出所有的页码 [每三个数据分一页]
        paginator = Paginator(students, 3)
        # 计算出中的数据数
        total = paginator.count
        # 获取到page_num对应的数据 使用int函数将page转换成数字
        pages = paginator.page(int(page_num))
        # 返回数据给前段去渲染
        return render(request, 'student.html', {'pages': pages, 'total': total})

        # 没做分页使用的是下面这条
        # return render(request, 'student.html', {'students': students})


"""
添加学生信息
"""


def addstudent(request):
    if request.method == 'GET':
        grades = list(Grade.objects.all())
        return render(request, 'addstudent.html', {'grades': grades})

    if request.method == 'POST':
        username = request.POST['username']
        tel = request.POST['tel']
        age = request.POST['age']
        s_yuwen = request.POST['s_yuwen']
        s_shuxue = request.POST['s_shuxue']
        g_id = request.POST['g_id']

    # 添加学生
    Student.objects.create(
        stu_name=username,
        stu_age=age,
        stu_tel=tel,
        stu_yuwen=s_yuwen,
        stu_shuxue=s_shuxue,
        g_id=g_id,
    )
    # 重定向到student.html页面
    return HttpResponseRedirect(reverse('wo:student'))


"""
删除学生信息
"""


def deletestu(request):
    if request.method == 'GET':
        #     pass
        # if request.method == 'POST':
        stu_id = request.GET.get('stu_id')
        # 真正的删除数据
        # stu =  Student.objects.filter(id=stu_id).delete()
        # 假删数据
        stu = Student.objects.filter(id=stu_id).first()
        stu.stu_delete = 1
        stu.save()
    # 自定义结果 这个结果是返回给前段ajax接收使用的
    msg = 200

    return HttpResponse(msg)


"""
编辑修改学生信息
"""


def editorstu(request):
    if request.method == 'GET':
        s_id = request.GET['s_id']
        data = Student.objects.filter(id=s_id).first()
        grades = Grade.objects.all()
        return render(request, 'addstudent.html', {'s_id': s_id, 'data': data, 'grades': grades})

    if request.method == 'POST':
        id = request.POST['id']
        username = request.POST['username']
        tel = request.POST['tel']
        age = request.POST['age']
        s_yuwen = request.POST['s_yuwen']
        s_shuxue = request.POST['s_shuxue']
        g_id = request.POST['g_id']

    # 修改数据
    Student.objects.filter(id=id).update(
        stu_name=username,
        stu_age=age,
        stu_tel=tel,
        stu_yuwen=s_yuwen,
        stu_shuxue=s_shuxue,
        g_id=g_id,
    )
    # 重定向到student.html页面
    return HttpResponseRedirect(reverse('wo:student'))


"""
学生信息的查询,可以支持多条件模糊查询
"""


def selectstu(request):
    # 如果是GET请求直接返回student页面
    if request.method == 'GET':
        return render(request, 'student.html')

    if request.method == 'POST':
        # 接收前段页面查询提交过来的数据
        username = request.POST['username']
        tel = request.POST['tel']
    # ----------------------下面----------------------------------------------------- #
    # # 通过姓名和电话查询出符合条件的学生这个地方要注意Q对象 和 & 的使用
    # students = Student.objects.filter(Q(stu_name__contains=username) & Q(stu_tel__contains=tel))
    # return render(request,'student.html',{'students':students})
    # ---------------------上面的注释是没有分页时候的写法-------------------------------- #
    page_num = request.POST.get('page_num', 1)
    # 获取所有的学生数据 ,我这有假删除的数据所以添加了一个过滤参数
    # 正常情况下应该是 students = list(Student.objects.all())
    # 通过姓名和电话查询出符合条件的学生这个地方要注意Q对象 和 & 的使用
    students = Student.objects.filter(Q(stu_name__contains=username) & Q(stu_tel__contains=tel))
    # 计算出所有的页码 [每三个数据分一页]
    paginator = Paginator(students, 3)
    # 计算出中的数据数
    total = paginator.count
    # 获取到page_num对应的数据 使用int函数将page转换成数字
    pages = paginator.page(int(page_num))

    return render(request, 'student.html', {'pages': pages, 'total': total})


"""
显示班级信息
"""


def grade(request):
    if request.method == 'GET':
        page_num = request.GET.get('page_num', 1)
        grades = list(Grade.objects.all())
        paginator = Paginator(grades, 3)
        total = paginator.count
        # 获取到page_num对应的数据 使用int函数将page转换成数字
        pages = paginator.page(int(page_num))

        return render(request, 'grade.html', {'pages': pages, 'total': total})


"""
添加班级信息
"""


def addgrade(request):
    if request.method == 'GET':
        return render(request, 'addgrade.html')
    if request.method == 'POST':
        gradename = request.POST['gradename']
        addr = request.POST['addr']
    Grade.objects.create(g_name=gradename, g_addr=addr)

    return HttpResponseRedirect(reverse('wo:grade'))
