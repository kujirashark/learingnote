from django.apps import AppConfig


class WoConfig(AppConfig):
    name = 'wo'
