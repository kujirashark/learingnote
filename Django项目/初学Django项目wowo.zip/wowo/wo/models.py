from django.db import models


# 创建班级model
class Grade(models.Model):
    g_name = models.CharField(max_length=20)
    g_addr = models.CharField(max_length=30)

    class Meta:
        db_table = 'tb_grade'


# 创建学生model
class Student(models.Model):
    stu_name = models.CharField(max_length=20)
    stu_age = models.CharField(max_length=2)
    stu_delete = models.BooleanField(default=0)
    stu_tel = models.CharField(max_length=11)
    stu_yuwen = models.IntegerField(null=True)
    stu_shuxue = models.IntegerField(null=True)
    g = models.ForeignKey(Grade)

    class Meta:
        db_table = 'tb_student'
