from django.conf.urls import url

from wo import views

urlpatterns = [
    # 首页
    url(r'^index/', views.index, name='index'),
    # 学生列表
    url(r'^student/', views.student, name='student'),
    # 班级列表
    url(r'^grade/', views.grade, name='grade'),
    # 添加学生
    url(r'addstudent/', views.addstudent, name='addstudent'),
    # 添加班级
    url(r'addgrade/', views.addgrade, name='addgrade'),
    # 编辑学生
    url(r'editorstu/', views.editorstu, name='editorstu'),
    # 删除学生
    url(r'deletestu/', views.deletestu, name='deletestu'),
    # 查询学生
    url(r'selectstu/', views.selectstu, name='selectstu'),

]
