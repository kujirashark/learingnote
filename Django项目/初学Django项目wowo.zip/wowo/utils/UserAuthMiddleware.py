from django.http import HttpResponseRedirect

from django.core.urlresolvers import reverse
from django.utils.deprecation import MiddlewareMixin

from user.models import Users

"""
定义中间件验证登录
"""


class UesrAuthMiddle(MiddlewareMixin):

    def process_request(self, request):
        # 获取的地址
        path = request.path
        s = ['/user/register/', '/user/login/']
        if path in s:
            return None

        ticket = request.COOKIES.get('ticket')

        # 如果没有ticket 就重定向到登录页面.
        if not ticket:
            return HttpResponseRedirect(reverse('user:login'))

        user = Users.objects.filter(ticket=ticket).first()

        # 如果没有uesr 就重定向到登录页面.
        if not user:
            return HttpResponseRedirect(reverse('user:login'))
        # request.user是全局的用户
        # 这里讲登录的用户赋值给 request.user
        request.user = user
